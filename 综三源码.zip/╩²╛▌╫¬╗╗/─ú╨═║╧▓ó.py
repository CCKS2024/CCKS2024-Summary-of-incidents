# 导入所需的库
from peft import AutoPeftModelForCausalLM
from transformers import AutoTokenizer

# 定义适配器路径和新模型保存目录
path_to_adapter = "qwen/output_qwen/checkpoint-800/"
new_model_directory = "qwen/output_qwen/model/qwen-1_8b-chat_model"

# 加载预训练模型
model = AutoPeftModelForCausalLM.from_pretrained(
    path_to_adapter,  # 适配器输出目录路径
    device_map="auto",
    trust_remote_code=True
).eval()

# 合并并卸载模型
merged_model = model.merge_and_unload()

# 保存合并后的模型
merged_model.save_pretrained(new_model_directory, max_shard_size="2048MB", safe_serialization=True)

# 加载分词器
tokenizer = AutoTokenizer.from_pretrained(
    path_to_adapter,  # 适配器输出目录路径
    trust_remote_code=True
)

# 保存分词器
tokenizer.save_pretrained(new_model_directory)
