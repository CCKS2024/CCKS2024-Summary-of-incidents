import json

# 读取以.jsonl结尾的文件
json_data = []

with open('D:/tianchi/data/round1_traning_data/train.json', 'r',
          encoding='utf-8') as file:
    for line in file:
        data = json.loads(line)
        json_data.append(data)

template = []

for idx, data in enumerate(json_data):
    for event in data["events"]:
        conversation = [
            {
                "from": "user",
                "value": event["content"]
            },
            {
                "from": "assistant",
                "value": next((summary["event-summarization"] for summary in data["summarizations"] if
                               summary["id"] == event["id"]), "")
            }
        ]

        template.append({
            "id": f"{event['id']}",
            "conversations": conversation
        })

print(len(template))
print(json.dumps(template[0], ensure_ascii=False, indent=2))

# 将template写入到本地文件
output_file_path = "./train_data.json"
with open(output_file_path, 'w', encoding='utf-8') as f:
    json.dump(template, f, ensure_ascii=False, indent=2)

print(f"处理好的数据已写入到本地文件: {output_file_path}")
